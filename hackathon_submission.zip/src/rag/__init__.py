# Initialization for rag
