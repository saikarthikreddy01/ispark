# Initialization for utils
