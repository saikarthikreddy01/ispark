# Initialization for agents
